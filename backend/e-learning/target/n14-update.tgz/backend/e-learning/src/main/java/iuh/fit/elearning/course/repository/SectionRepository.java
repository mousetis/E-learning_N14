package iuh.fit.elearning.course.repository;

import iuh.fit.elearning.course.entity.Section;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface SectionRepository extends JpaRepository<Section, UUID> {

    List<Section> findByCourseIdOrderByOrderIndexAsc(UUID courseId);
}
